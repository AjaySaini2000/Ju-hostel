import React from 'react'

const Protected_Routes = () => {
  return (
    <div>Protected_Routes</div>
  )
}

export default Protected_Routes