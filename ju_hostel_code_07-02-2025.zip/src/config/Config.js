export const BaseUrl='https://rasatva.apponedemo.top/hostel-web/api/'
export const SecretKey='Juhostel'
export const ImageUrl='https://rasatva.apponedemo.top/hostel-web/public/'