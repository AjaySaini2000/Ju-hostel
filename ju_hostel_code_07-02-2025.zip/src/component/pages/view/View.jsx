import React from 'react'

const View = () => {
  return (
  <div>
  <div className="top_space pt-80" />
  <iframe src="https://my.matterport.com/show/?m=cA5ehC3ioSu&play=1" frameBorder={0} width="100%" height={650} allowFullScreen />
</div>

  )
}

export default View