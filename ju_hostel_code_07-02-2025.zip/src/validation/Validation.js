import React from 'react'

const Validation = () => {
  return (
    <div>Validation</div>
  )
}

export default Validation